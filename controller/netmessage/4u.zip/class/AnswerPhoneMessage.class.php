<?php
class AnswerPhoneMessage extends VoiceMessage
{
	/**
	 * 
	 * @return void
	 */
	function __construct()
	{
		parent::__construct();
	}
}
?>