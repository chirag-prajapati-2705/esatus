<?php

class WavListResultCollection extends ResultCollection
{
	
	
		/** @var WavObject[] */
	public $WavObjects;
	
	
	
	
	function __construct()
	{

		$this->WavObjects=array();
		parent::__construct();
		
	}
	
	
	
	
	
}



?>