<?php

class MailAttachment
{
	
	/** @var string */
	public $Name;
	
	/** @var string */
	public $Content;
	
	
	function __construct()
	{
		$this->Content="";
		$this->Name="";
		
		
		
	}
	
	
	
	
}







?>