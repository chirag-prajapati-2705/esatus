<?php
class CustomField
{
	
	/** @var string */
	public $Label;
	
	/** @var string */
	public $Content;
	
	function __construct()
	{
		$this->Label="";
		$this->Content="";
	}
	
	
	
}




?>