<?php

class MailImage
{
	
	/** @var string */
	public $Name;
	
	/** @var string */
	public $Content;
	
	/** @var int */
	public $Type;
	
	function __construct()
	{
		$this->Content="";
		$this->Name="";
		$this->Type=0;
		
		
	}
	
	
	
	
}







?>