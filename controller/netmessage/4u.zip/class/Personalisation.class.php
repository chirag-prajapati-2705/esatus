<?php
class Personalisation
{
	
	protected $withoutPersoMessage;
	/** @var string[] **/
    public $Perso;
	
    function __construct()
    {
    	$this->Perso=array();
    	
    	
    }

	
	
}
?>