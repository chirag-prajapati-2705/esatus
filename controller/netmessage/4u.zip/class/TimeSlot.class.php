<?php
/**
 * Periode blackout repr�sentant le time slot
 */

class TimeSlot
{
	
	/** @var string */
	public $TimeStart;
	
	/** @var string */
	public $TimeEnd;
	
	
	
	function __construct()
	{
	$this->TimeEnd="";;
	$this->TimeStart="";
		
		
	}
	
	
	
} 



?>