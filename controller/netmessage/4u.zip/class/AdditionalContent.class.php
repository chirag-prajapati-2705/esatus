<?php
class AdditionalContent
{
	/** @var string */
	public $Type;
	
	/** @var string */
	public $Content;
	
	/** @var string */
	public $Name;
	
}






?>