<?php
/**
 * Message Wav
 * 
 *
 */
class WavMessage
{
	
	
	/** @var int */
	public $Key;
	
	/** @var string */
	public $Server;
	
	/**
	 * 
	 * @return void
	 */
	function __construct()
	{
		
		$this->Key=0;
		$this->Server="";
		
	}
	
}
?>