<?php
class Sms2WaysFilter extends ListFilter
{
	
	/** @var string */
	public $SmsDestination;
	/** @var string */
	public $Keyword;
	
	/** @var string */
	public $SmsData;
	
	
	
	function __construct()
	{
		$this->SmsDestination="";
		$this->Keyword="";
		$this->SmsData="";
		
		parent::__construct();
	}
	
	
	
	
	
}


?>