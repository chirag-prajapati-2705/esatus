<?php
/**
 * class d�di�e aux scenario de script vocaux
 */

include_once("VoiceScriptResult.class.php");

class ScriptScenario
{
	
	/** @var VoiceScriptResult */
	public $VoiceScript;
	
	
	function __construct()
	{
		
		
		
		
	}
	
	
	
	
	
}






?>