<?php
class MailEvent
{
	
	/** @var string */
	public $Action;
	
	/** @var string */
	public $ActionTime;
	
	function __construct()
	{
		
		$this->Action="";
		$this->ActionTime="";
		
	}
	
	
}